<?php
    include("zaglavlje.php");
    $veza=spojiSeNaBazu();
?>
<body>
<div class="azuriranje">
    <?php
        $poruka="";
    	if(isset($_GET['azuriraj'])){ ?>
        
        <form name='azuriraj' method='POST' action="<?php echo $_SERVER["PHP_SELF"] . "?id=$valuta"; ?>">
        <?php 
            echo "<label for='iznos'>Iznos: </label>"; 
            echo "<input name='iznos' type='number' />";
            
            echo "<input name='submit' type='submit' value='Ažuriraj' />";
            echo "</form>";
            ?>
            <?php
            if(isset($_POST['submit'])){
                $valuta = $_GET["id"];
                $azuriran = $_POST['iznos'];

                $update="SELECT * FROM sredstva WHERE valuta='$azuirian' AND korisnik_id=$aktivni_korisnik_id";
                $upit3=izvrsiUpit($veza, $update);

                $updatev="UPDATE sredstva SET iznos = $azuriran WHERE sredstva_id=$valuta";
                izvrsiUpit($veza, $updatev);
                $poruka="Azurirali ste sredstva (ID: $valuta)";
            }
        }
    ?>
</div>
<body>
<?php
    zatvoriVezuNaBazu($veza);
    include("podnozje.php");
?>
