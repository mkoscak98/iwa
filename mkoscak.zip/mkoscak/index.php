<?php 
session_start();
include "zaglavlje.php" 
?>

<body>
	<section class="opis">
		<p>Dobro došli na stranicu "Virtualna mjenjačnica". 
		<br><br>
		U ovom projektu odnosno web aplikaciji moći će se 
		pregledati valute te informacije o svakoj,<br> 
		zatim pregledati korisnici, zahtjevi, koliko 
		imamo sredstva na računu kao prijavljeni korisnik, itd. </p>	    
	</section>
		

<footer>
<?php include_once("podnozje.php")?>
</footer>
</body>

