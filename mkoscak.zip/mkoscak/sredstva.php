<?php
  include("zaglavlje.php");
  $veza=spojiSeNaBazu();

  if(isset($_SESSION['aktivni_korisnik'])){
    $aktivni_korisnik=$_SESSION['aktivni_korisnik'];
    $aktivni_korisnik_ime=$_SESSION['aktivni_korisnik_ime'];
    $aktivni_korisnik_tip=$_SESSION['aktivni_korisnik_tip'];
    $aktivni_korisnik_id=$_SESSION["aktivni_korisnik_id"];
}
?>
<div class="sredstva" id="sredstva">
    <?php
        $sql = "SELECT s.iznos, v.valuta_id, v.naziv FROM sredstva s, valuta v WHERE s.valuta_id=v.valuta_id AND korisnik_id = '$aktivni_korisnik_id'";
        $upit = izvrsiUpit($veza, $sql);

        echo '<table class="tablica">';
        echo '<caption>Moja sredstva</caption>';
		echo '<thead>';
		echo '<tr>';
		echo '<th>Naziv</th>';
		echo '<th>Iznos</th>';
		echo '<th>Promijeni iznos</th>';
		echo '</tr></thead>';
			
		echo '<tbody>';
            while($red = mysqli_fetch_array($upit)){
                $iznos = $red['iznos'];
                $naziv = $red['naziv'];
                $id = $red['valuta_id'];
            
        echo '<tr>';    
        echo "<td>".$naziv. "</td>";
        echo "<td>" .$iznos. "</td>";
        echo '<td><a class="azuriraj" href="azuriraj.php?azuriraj='.$id.'">Ažuriraj iznos</a></td>';
        echo '</tr>';    
            }     
        ?>
</div>

<div class="dodaj">
        <?php
                $sql1 = "SELECT valuta_id, naziv  FROM valuta";
                $upit1 = izvrsiUpit($veza, $sql1);

                echo "<form name='obrazac' id='obrazac' action='sredstva.php' method='POST'>";
                echo "<span>Dodajte novi iznos: </span>";
                echo "<label for='valuta'>Valuta: </label>";
                echo "<select name='valuta'>";

                    while($rs=mysqli_fetch_array($upit1)){
                        $id = $rs['valuta_id'];
                        $naziv = $rs['naziv'];
                        echo '<option value="'.$id.'" >'.$naziv.'</option>';
                    }
                echo "</select>";

                echo "<label for='iznos'>Iznos: </label>"; 
                echo "<input name='iznos' type='number' />";
                echo "<input name='dodaj' type='submit' value='Unesi' />";
                echo "</form>";
                
                if(isset($_POST['dodaj'])){
                    $valuta = $_POST['valuta'];
                    $iznosv = $_POST['iznos'];
                    
                    $dodaj="SELECT * FROM sredstva WHERE valuta_id='valuta' AND korisnik_id=$aktivni_korisnik_id";
                    $upit2=izvrsiUpit($veza, $dodaj);

                    $dodajv="INSERT INTO sredstva VALUES (default, '$aktivni_korisnik_id', '$valuta', '$iznosv') ";
                    izvrsiUpit($veza, $dodajv);

                    
                }
        ?>
</div>
<?php
    zatvoriVezuNaBazu($veza);
	include("podnozje.php");
?>