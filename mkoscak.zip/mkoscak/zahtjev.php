<?php
    include("zaglavlje.php");
    $veza=spojiSeNaBazu();

    if(isset($_SESSION['aktivni_korisnik'])){
		$aktivni_korisnik=$_SESSION['aktivni_korisnik'];
		$aktivni_korisnik_ime=$_SESSION['aktivni_korisnik_ime'];
		$aktivni_korisnik_tip=$_SESSION['aktivni_korisnik_tip'];
        $aktivni_korisnik_id=$_SESSION["aktivni_korisnik_id"];
    }
    
    $greska="";
?>

<?php
    $sql="SELECT * FROM zahtjev";
    $upit=izvrsiUpit($veza, $sql);

    $sql1="SELECT * FROM valuta";
    $upit1=izvrsiUpit($veza, $sql);

     $datum = date("Y-m-d h:i:s");
     $iznos=$_POST['iznos'];
     $id_prodajem=$_GET['id_prodajem']
     $prodajem=$_POST['prodajem'];
     $kupujem=$_POST['kupovna'];
     $dostupno=$_GET['dostupni_iznos'];

    if(empty($_POST)){
        $greska="Morate unesti sve podatke!";
    }
    if($_POST['iznos'] > $_GET['prodajem']){
        $greska="Nedovoljan iznos za prodaju!";
    }

     if(isset($_POST['submit'])){
         $novi="INSERT INTO zahtjev VALUES (default, '$aktivni_korisnik_id', '{$iznos}', '$kupujem', '$prodajem', '$datum', 2)";
         $insert=izvrsiUpit($veza,$novi);
     }
?>

<h2 style="text-align: center;">Unesite iznos:</h2>
<div class="prodaja" style="margin-top:10px;margin-left:0px;border-style:solid;padding:10px; margin-right:60%;height:150px;box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);background-color:whitesmoke;">
     <form name="prodaja" method="POST" action="zahtjev.php<?php echo "?idprodaja=" .$id_prodajem.'&prodajem=' .$prodajem.''?>">
     <label>Iznos: </label>
     <input name="iznos" type="number"/>
        <?php
            echo '<select name="kupujem">'
            while($r=mysqli_fetch_array($upit1)){
                echo '<option value="'.$r[0]'" >'.$r[2].'</option>';
            }
            echo '</select>';
        ?>
    <input type="submit"  name="submit" value="Prodaj"/>;


#odabir svih zahtjeva korisnika 3
SELECT 
(SELECT naziv FROM valuta WHERE valuta_id=prodajem_valuta_id) as prodajem,
(SELECT naziv FROM valuta WHERE valuta_id=kupujem_valuta_id) as kupujem,
iznos as prodajni_iznos, prihvacen FROM zahtjev WHERE korisnik_id=3