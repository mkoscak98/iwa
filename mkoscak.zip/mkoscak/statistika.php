<?php
    include("zaglavlje.php");
    include_once("baza.php");

    $veza=spojiSeNaBazu();


?>

<div class="obrazac">
<h2>Filtritajte podatke</h2>

<form name="obrazac" class="obrazac" method="POST" action="statistika.php" >
    <label for="moderator"><strong>Moderator: </strong></label> 
        <?php
            $sql="SELECT * FROM korisnik WHERE tip_korisnika_id=1";
            $rs=izvrsiUpit($veza, $sql);

            echo '<select name="moderator">';
            while(list($korisnik, $tip, $korisnicko)=mysqli_fetch_array($red)){
            echo '<option value="'.$korisnik.'">'.$korisnicko.'</option>';
            }
            echo '</select><br><br>';
            
        ?>

		<label for="datum_od"><strong>Od:</strong></label>
        <input name="datum_od" type="text" placeholder="00-00-0000 00:00:00"/><br><br>
        <label for="datum_do"><strong>Do:</strong></label>
        <input name="datum_do" type="text" placeholder="00-00-0000 00:00:00"/><br><br>	
		<input name="submit" type="submit" value="Filtriraj"/>
</form>
</div>

<?php
    $moderator=$_POST["moderator_id"];
    $vrijeme_od= "01-01-2018 00:00:00";
    $vrijeme_do= "12-31-2018 23:55:55";
    if(isset($_POST['moderator']) && isset($_POST['datum_od']) && isset($_POST['datum_do'])) {
        $moderator = $_POST['moderator'];
        $vrijeme_od = date("d-m-Y H:i:s", strtotime( $_POST['datum_od']));
        $vrijeme_do = date("Y-m-d H:i:s", strtotime( $_POST['datum_do']));
    }
    
    $sql="SELECT v.naziv, SUM(z.iznos) as ukupno_prodani_iznos FROM valuta v, zahtjev z 
    WHERE v.valuta_id=z.prodajem_valuta_id AND z.prihvacen=1 AND moderator_id=$moderator 
    AND datum_vrijeme_kreiranja BETWEEN '2018-01-01 00:00:00' AND '2018-12-31 23:55:55'
    GROUP BY v.valuta_id ORDER BY ukupno_prodani_iznos DESC";
      
    $rs=izvrsiUpit($veza,$sql);

    echo '<table class="statistika">';
    echo '<h2>Ukupan iznos prema moderatoru</h2>';

    echo "<thead><tr>
    <th>Naziv valute</th>
    <th>Ukupan iznos prodanih</th>";
    echo "</tr></thead>";
        echo "<tbody>";
        while(list($naziv,$suma)=mysqli_fetch_array($rs)){
            echo "<tr><td>$naziv</td>
                    <td>$suma</td>";
            echo "</tr>";
        }
        echo "</tbody>";
    echo "</table>";
?>
  
<?php
    zatvoriVezuNaBazu($veza);
	include("podnozje.php");
?>