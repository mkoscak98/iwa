<?php
	include("zaglavlje.php");
	include_once("baza.php");
	$veza=spojiSeNaBazu();
	$greska = "";
	$poruka = "";
?>
<?php
	if(isset($_GET['logout'])){
		unset($_SESSION["aktivni_korisnik"]);
		unset($_SESSION['aktivni_korisnik_ime']);
		unset($_SESSION["aktivni_korisnik_tip"]);
		unset($_SESSION["aktivni_korisnik_id"]);
		session_destroy();
		header("Location:index.php");
	}

	if(isset($_POST["submit"])){

		$kor_ime=mysqli_real_escape_string($veza,$_POST['korisnicko_ime']);
		$lozinka=mysqli_real_escape_string($veza,$_POST['lozinka']);
		
		if (!empty($kor_ime) && !empty($lozinka)) {

			$sql = "SELECT korisnik_id, tip_korisnika_id, ime, prezime FROM korisnik WHERE korisnicko_ime='$kor_ime' AND lozinka = '$lozinka'";
			$red = mysqli_query($veza, $sql);

			if(mysqli_num_rows($red) == 0) {
				$greska = "Ne postoji korisnik s navedenim usernameom i passwordom";
			} else {
				
				list($id, $tip_id, $ime, $prezime) = mysqli_fetch_array($red);
				$_SESSION['korisnik_id'] = $id;
				$_SESSION['aktivni_korisnik'] = $korisnicko_ime;
				$_SESSION['aktivni_korisnik_ime'] = $ime . " " . $prezime;
				$_SESSION['aktivni_korisnik_tip'] = $tip_id;
				header("Location:index.php");
			}
		} 
			else
			$greska = "Unesite korisnicko ime i lozinku";
		}
		zatvoriVezuNaBazu($veza);
?>

<form id="prijava" name="prijava" method="POST" action="<?php echo $_SERVER["PHP_SELF"];?>">
	<h2>Prijava u sustav</h2>
		<label class="greska"><?php if($greska!="")echo $greska; ?></label>
		<label for="korisnicko_ime"><strong>Korisničko ime: </strong></label>
		<input name="korisnicko_ime" id="korisnicko_ime" type="text" size="20"/><br><br>
		<label for="lozinka"><strong>Lozinka:</strong></label>
		<input name="lozinka"	id="lozinka" type="password" size="20" minlength="6"/><br><br>
		<input name="submit" type="submit" value="Prijavi se"/>
</form>
<?php
	include("podnozje.php");
?>
