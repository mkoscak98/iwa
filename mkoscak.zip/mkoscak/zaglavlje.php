<?php
	include("baza.php");
	if(session_id()=="")session_start();

	$trenutna=basename($_SERVER["PHP_SELF"]);
	$putanja=$_SERVER['REQUEST_URI'];
	$aktivni_korisnik=2;
	$aktivni_korisnik_tip=-1;

	if(isset($_SESSION['aktivni_korisnik'])){
		$aktivni_korisnik=$_SESSION['aktivni_korisnik'];
		$aktivni_korisnik_ime=$_SESSION['aktivni_korisnik_ime'];
		$aktivni_korisnik_tip=$_SESSION['aktivni_korisnik_tip'];
		$aktivni_korisnik_id=$_SESSION["aktivni_korisnik_id"];
	}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Virtualna mjenjačnica</title>
		<meta name="autor" content="Košćak Marinela"/>
		<meta name="datum" content="12.8.2020."/>
		<meta charset="utf-8"/>
		<link href="mkoscak.css" rel="stylesheet" type="text/css"/>
		
	</head>
	<body>
		<header>
			<h1 style="height: 55px; text-align: center; 
			letter-spacing: 5px;">Virtualna mjenjačnica</h1>
		</header>
		<nav class="navigacija">
			
		<?php if(isset($_SESSION["aktivni_korisnik_tip"]) && $_SESSION["aktivni_korisnik_tip"] ==0){ 
			echo '<a href="index.php">Početna</a>';
			echo '<a href="statistika.php">Statistika</a>';
			echo '<a href="korisnici.php">Korisnici</a>';
			echo '<a href="sredstva.php" >Račun</a>';
			echo '<a href="valute.php" >Valute</a>';
			echo '<a href="zahtjevi.php" >Popis Zahtjeva</a>';
			echo '<a href="o_autoru.html">O autoru</a>';
			echo '<a style="float:right" href="prijava.php?logout=0">Odjava</a>';
		}  
		?>
		
		<?php if(isset($_SESSION["aktivni_korisnik_tip"]) && $_SESSION["aktivni_korisnik_tip"] ==1){
			echo '<a href="index.php">Početna</a>';
			echo '<a href="sredstva.php" >Račun</a>';
			echo '<a href="valute.php" >Valute</a>';
			echo '<a href="zahtjevi.php" >Popis Zahtjeva</a>';
			echo '<a href="o_autoru.html">O autoru</a>';
			echo '<a style="float:right" href="prijava.php?logout=1">Odjava</a>';
		}  
		?>
	
		<?php if(isset($_SESSION["aktivni_korisnik_tip"]) && $_SESSION["aktivni_korisnik_tip"] ==2){
			echo '<a href="index.php">Početna</a>';
			echo '<a href="sredstva.php" >Račun</a>';
			echo '<a href="valute.php" >Valute</a>';
			echo '<a href="o_autoru.html">O autoru</a>';
			echo '<a style="float:right" href="prijava.php?logout=2">Odjava</a>';
		}  
		?>

		<?php if(!isset($_SESSION["aktivni_korisnik_tip"])){
			echo '<a href="index.php">Početna</a>';
			echo '<a style="float:right" href="prijava.php">Prijava</a>';
			echo '<a href="valute.php" >Valute</a>';
			echo '<a href="o_autoru.html">O autoru</a>';
		}
		?>	

		</nav>
	</body>